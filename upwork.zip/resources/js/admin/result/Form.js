import AppForm from '../app-components/Form/AppForm';

Vue.component('result-form', {
    mixins: [AppForm],
    data: function() {
        return {
            form: {
                path:  '' ,
                user_id:  '' ,
                
            }
        }
    }

});