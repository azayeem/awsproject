import AppListing from '../app-components/Listing/AppListing';

Vue.component('user-listing', {
    mixins: [AppListing]
});