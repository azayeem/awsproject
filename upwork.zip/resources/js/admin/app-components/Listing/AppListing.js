import { BaseListing } from 'craftable';

export default {
	mixins: [BaseListing]
};