<?php

return [
    'admin-user' => [
        'title' => 'Users',

        'actions' => [
            'index' => 'Users',
            'create' => 'New User',
            'edit' => 'Edit :name',
            'edit_profile' => 'Edit Profile',
            'edit_password' => 'Edit Password',
        ],

        'columns' => [
            'id' => "ID",
            'first_name' => "First name",
            'last_name' => "Last name",
            'email' => "Email",
            'password' => "Password",
            'password_repeat' => "Password Confirmation",
            'activated' => "Activated",
            'forbidden' => "Forbidden",
            'language' => "Language",
                
            //Belongs to many relations
            'roles' => "Roles",
                
        ],
    ],

    'user' => [
        'title' => 'Users',

        'actions' => [
            'index' => 'Users',
            'create' => 'New User',
            'edit' => 'Edit :name',
        ],

        'columns' => [
            'id' => "ID",
            'name' => "Name",
            'email' => "Email",
            'email_verified_at' => "Email verified at",
            'password' => "Password",
            'created_at' => "Date of registration",
            'birth_date' => "Date of Birth",
            'user_verified' => "User verification status"

        ],
    ],

    'result' => [
        'title' => 'Results',

        'actions' => [
            'index' => 'Results',
            'create' => 'New Result',
            'edit' => 'Edit :name',
        ],

        'columns' => [
            'id' => "ID",
            'path' => "Path",
            'user_id' => "User",
            'birth_date' => "Birth Date",
            'results_filled_date' => "Time of survey",

        ],
    ],

    // Do not delete me :) I'm used for auto-generation
];
