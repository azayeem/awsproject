<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">



    <title>Registration page</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css"
          integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css"
          integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ secure_asset('css/styles.css') }}">

</head>
<body>


<div class="wrapper">
    <header class="header">
        <div class="header-inner">
            <a href="#" class="header-logo logo for-img">
                <img src="{{secure_asset('images/web/logo.png')}}" alt="MaculaScan">
            </a>
        </div>
    </header>
    <div class="auth-wrap">
        <div class="auth-left"></div>
        <div class="auth-right">
            <div class="auth-header">
                <h1 class="auth-title">
                    Welcome to <span class="main-text">MaculaScan <sup>TM</sup></span>
                    <span class="title-logo for-img">
							<img src="{{secure_asset('images/web/logo_sm.jpg')}}" alt="">
						</span>
                </h1>
                <p class="auth-subtitle">Create your account</p>
            </div>
            <div class="alert alert-danger" style="display:none"></div>
            <form id="submit-register-form" class="auth-form" method="post" action="{{ secure_url('/register') }}">
                {{ csrf_field() }}
                <div class="form-group">
                    <label for="name" class="form-label visually-hidden"></label>
                    <input id="name" type="text" name="name" class="form-text" placeholder="Navn*">
                    <span class="form-icon"><i class="fal fa-user"></i></span>
                </div>
                <div class="form-group">
                    <label for="email" class="form-label visually-hidden"></label>
                    <input id="email" type="email" name="email" class="form-text" placeholder="Email*">
                    <span class="form-icon"><i class="fal fa-envelope"></i></span>
                </div>
                <div class="form-group">
                    <label for="password" class="visually-hidden"></label>
                    <input id="password" type="password" name="password" class="form-text" placeholder="Password*">
                    <span class="form-icon"><i class="fal fa-key"></i></span>
                </div>
                <div class="form-group">
                    <label for="confirm-password" class="form-label visually-hidden"></label>
                    <input id="password_confirmation" name="password_confirmation" type="password" class="form-text"
                           placeholder="Confirm Password*">
                    <span class="form-icon"><i class="fal fa-key"></i></span>
                </div>

                <div class="form-group">
                    @if(env('6Lej6MwUAAAAAHhWy73QOc_YFAp8hdvywNvb85x-'))
                         <div class="g-recaptcha"
                              data-sitekey="{{env('6Lej6MwUAAAAAHhWy73QOc_YFAp8hdvywNvb85x-')}}">
                         </div>
                    @endif
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn_lg">Create account</button>
                </div>
            </form>
            <div class="auth-footer">
                <a href="{{route('about')}}" class="link">About MaculaScan <i class="fal fa-arrow-right"></i></a>
            </div>
        </div>
    </div>
    <div class="footer"></div>
    <button class="up-btn" aria-label="to top button"><i class="fal fa-arrow-up"></i></button>
</div>

<div class="popup-overlay">
    <div class="popup">
        <div class="success-mail-img for-img">
            <img src="{{secure_asset('images/web/mail.svg')}}" alt="">
        </div>
        <p>Thank you for registering for the MaculaScan™ app.</p>
        <p>We will send you a confirmation email once your registration has been confirmed.</p>
        <br/>
        <p>Thank you again.</p>
        <p>The MaculaScan™ Team</p>
        <button id="hide-popup" class="btn btn_lg">Ok</button>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script>
    $(document).ready(function () {

        $("#submit-register-form").on('submit', function (e) {


            e.preventDefault();

            var name = $("#name").val();
            var email = $("#email").val();
            var password = $("#password").val();
            var passwordConfirmation = $("#password_confirmation").val();

            $.ajax({
                type: 'POST',
                url: "{{ url('/register') }}",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                },
                data: {name: name, password: password, email: email, password_confirmation: passwordConfirmation},
                success: function (data) {
                    if (data.success === true) {
                        $('.alert-danger').empty().hide();
                        $('.popup-overlay').css('visibility', 'visible').css('opacity', 1);
                        document.getElementById("submit-register-form").reset();
                    }

                    if (data.errors) {
                        var errors = data.errors;
                        $('.alert-danger').empty();
                        $.each(errors, function (key, value) {
                            if ($.isPlainObject(value)) {
                                $('.alert-danger').empty();
                                $.each(value, function (key, value) {
                                    $('.alert-danger').show().append(value + "<br/>");

                                });
                            } else {
                                $('.alert-danger').show().append(value + "<br/>");
                            }
                        });
                    }
                },
                error: function (data) {
                    if (data.status === 422) {
                        var errors = $.parseJSON(data.responseText);

                        $.each(errors, function (key, value) {
                            if ($.isPlainObject(value)) {
                                $('.alert-danger').empty();
                                $.each(value, function (key, value) {
                                    $('.alert-danger').show().append(value + "<br/>");
                                });
                            } else {
                                $('.alert-danger').show().append(value + "<br/>");
                            }
                        });
                    }
                }
            });
        });


        $('#hide-popup').on('click', function () {
            $('.popup-overlay').css('visibility', 'hidden').css('opacity', 0);
        });
    });

</script>

<script src='https://www.google.com/recaptcha/api.js'></script>

</body>
</html>
