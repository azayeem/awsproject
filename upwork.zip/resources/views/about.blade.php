<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>About page</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css"
          integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css"
          integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ secure_asset('css/styles.css') }}">

</head>
<body>

<div class="wrapper">

    <header class="header">
        <div class="header-inner">
            <a href="#" class="header-logo logo for-img">
                <img src="{{secure_asset('images/web/logo.png')}}" alt="MaculaScan">
            </a>
            <a href="{{route('register/user')}}" class="link">Registration Form <i class="fal fa-arrow-right"></i></a>
        </div>
    </header>
    <div class="about-wrap">
        <div class="about-col">
            <div class="about-img">
                <div class="about-img-descr">Jørgen Bruun-Jensen, MD</div>
            </div>
        </div>
        <div class="about-col">
            <div class="about-col-inner">
                <div class="about-text">
                    <h1 class="about-title">
                        About <span class="main-text">MaculaScan <sup>TM</sup></span>
                        <span class="title-logo for-img">
								<img src="{{secure_asset('images/web/logo_sm.jpg')}}" alt="">
							</span>
                    </h1>
                    <h2>Imagine if we could save the eye sight of people with diabetic retinopathy or AMD and get them on the right treatment early</h2>
                    <p>Many people with macula diseases have no or only late access to high-tech eye examinations. Therefore, innovative strategies are needed to evaluate the visual integrity of the macula and for early detection of macula diseases. MaculaScan    was developed by Dr. Jørgen Bruun-Jensen, MD as a software application for a tablet device, such as an iPad.</p>
                    <p>The digital part of MaculaScan    was developed by Dr. Jacob Bruun-Jensen and Scan Vision Ltd., England. It was tested with groups of patients with diabetes, age-related macular degeneration and vitreoretinal diseases. Screening of patients without visual symptoms of macula disease was performed by optometrists and by health care in-home visits.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="about-wrap">
        <div class="about-col about-col-graph">
            <div class="about-col-inner">
                <figure class="about-gruph-img for-img">
                    <figcaption>Estimated number of patients worldwide [Millions]</figcaption>
                    <img src="{{secure_asset('images/web/about-graph.png')}}" alt="Trulli">
                </figure>
            </div>
        </div>
        <div class="about-col">
            <div class="about-col-inner">
                <div class="about-text">
                    <h2>Vision scanning with the MaculaScan   can help screen for and follow-up on Diabetic Retinopathy and Age-related Macular Degeneration (AMD)</h2>
                    <p>64 million people are estimated to have diabetic retinopathy and that is likely to increase to 100 million by 2030 . The longer a person has diabetes the more likely they are to develop retinopathy.</p>
                    <p>131 million people are estimated to have AMD and that is expected to grow to 221 million by 2030 .</p>
                </div>
                <div class="about-col-footer">Source: (1) IDF, June 2010; (2) Vision 2020/IAPB June 2010</div>
            </div>
        </div>
    </div>
    <div class="footer"></div>
    <button class="up-btn" aria-label="to top button"><i class="fal fa-arrow-up"></i></button>
</div>



</body>
</html>
