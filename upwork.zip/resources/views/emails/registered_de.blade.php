<!DOCTYPE html>
<html style="height: 100%; margin: 0; padding: 0; background-color: #e0e0e040;">
<head>
    <title>MaculaScan</title>
</head>
<body
    style="height: 100%; margin: 0; padding: 0;  background-color: #e0e0e040; text-align: center; font-family: sans-serif; font-size: 18px; line-height: 1.5; color: #808080;">

<table style="display: inline-table; width: 100%; max-width: 600px; text-align: left;">
    <tr>
        <td style="padding: 10px 0; text-align: center;">
            <img src="{{secure_asset('images/web/logo.png')}}" alt="MaculaScan" style="width: 250px;">
        </td>
    </tr>
    <tr>
        <td><p>Sehr geehrte/r [xxxxx],
                Vielen Dank, dass Sie sich für die MaculaScan™-App registriert haben. Wir werden Ihnen eine Bestätigungsmail zusenden, sobald Ihre Registrierung bestätigt wurde.


                <br/>
                Mit freundlichen Grüßen,
                Ihr MaculaScan™ Team</p>
        </td>
    </tr>
</table>
</body>
</html>
