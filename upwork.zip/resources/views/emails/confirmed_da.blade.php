<!DOCTYPE html>
<html style="height: 100%; margin: 0; padding: 0; background-color: #e0e0e040;">
<head>
    <title>MaculaScan</title>
</head>
<body
    style="height: 100%; margin: 0; padding: 0;  background-color: #e0e0e040; text-align: center; font-family: sans-serif; font-size: 18px; line-height: 1.5; color: #808080;">

<table style="display: inline-table; width: 100%; max-width: 600px; text-align: left;">
    <tr>
        <td style="padding: 10px 0; text-align: center;">
            <img src="{{secure_asset('images/web/logo.png')}}" alt="MaculaScan" style="width: 250px;">
        </td>
    </tr>
    <tr>
        <td>
            <h2><strong>Kære {{$username}},</strong></h2>
        </td>
    </tr>
    <tr>
        <td><p>Endnu engang tak fordi at du registrerede på MaculaScan™.
                Din konto er nu bekræftet og du kan bruge programmet. Du skal åbne MaculaScan™ programmet på din iPad og
                logge ind med den email og password som du brugte da du registrerede. Når du engang har logget ind, så
                behøver du ikke at gøre det igen.
                Med venlig hilsen,
                <br/>
                MaculaScan™ Team</p>
        </td>
    </tr>
</table>
</body>
</html>
