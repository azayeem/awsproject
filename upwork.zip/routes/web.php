<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


/* Auto-generated admin routes */
Route::middleware(['auth:' . config('admin-auth.defaults.guard'), 'admin'])->group(function () {
    Route::get('/admin/admin-users',                            'Admin\AdminUsersController@index');
    Route::get('/admin/admin-users/create',                     'Admin\AdminUsersController@create');
    Route::post('/admin/admin-users',                           'Admin\AdminUsersController@store');
    Route::get('/admin/admin-users/{adminUser}/edit',           'Admin\AdminUsersController@edit')->name('admin/admin-users/edit');
    Route::post('/admin/admin-users/{adminUser}',               'Admin\AdminUsersController@update')->name('admin/admin-users/update');
    Route::delete('/admin/admin-users/{adminUser}',             'Admin\AdminUsersController@destroy')->name('admin/admin-users/destroy');
    Route::get('/admin/admin-users/{adminUser}/resend-activation','Admin\AdminUsersController@resendActivationEmail')->name('admin/admin-users/resendActivationEmail');
});

/* Auto-generated profile routes */
Route::middleware(['auth:' . config('admin-auth.defaults.guard'), 'admin'])->group(function () {
    Route::get('/admin/profile',                                'Admin\ProfileController@editProfile');
    Route::post('/admin/profile',                               'Admin\ProfileController@updateProfile');
    Route::get('/admin/password',                               'Admin\ProfileController@editPassword');
    Route::post('/admin/password',                              'Admin\ProfileController@updatePassword');
});

/* Auto-generated admin routes */
Route::middleware(['auth:' . config('admin-auth.defaults.guard'), 'admin'])->group(function () {
    Route::get('/admin/users',                                  'Admin\UsersController@index');
    Route::get('/admin/users/create',                           'Admin\UsersController@create');
    Route::post('/admin/users',                                 'Admin\UsersController@store');
    Route::get('/admin/users/{user}/edit',                      'Admin\UsersController@edit')->name('admin/users/edit');
    Route::post('/admin/users/{user}',                          'Admin\UsersController@update')->name('admin/users/update');
    Route::delete('/admin/users/{user}',                        'Admin\UsersController@destroy')->name('admin/users/destroy');
    Route::post('/admin/users/{user}/verification',             'Admin\UsersController@verification')->name('user/verification');
});

/* Auto-generated admin routes */
Route::middleware(['auth:' . config('admin-auth.defaults.guard'), 'admin'])->group(function () {
    Route::get('/admin/results',                                'Admin\ResultsController@index');
    Route::get('/admin/results/create',                         'Admin\ResultsController@create');
    Route::post('/admin/results',                               'Admin\ResultsController@store');
    Route::get('/admin/results/{result}/edit',                  'Admin\ResultsController@edit')->name('admin/results/edit');
    Route::post('/admin/results/{result}',                      'Admin\ResultsController@update')->name('admin/results/update');
    Route::delete('/admin/results/{result}',                    'Admin\ResultsController@destroy')->name('admin/results/destroy');
});


Route::get('/','PageController@pageRegister')->name('register/user');
Route::get('/about-us','PageController@pageAboutUs')->name('about');
Route::post('/register','Auth\RegisterController@register');



// Download Route
Route::middleware(['auth:' . config('admin-auth.defaults.guard'), 'admin'])
    ->get('/download/{filename}', 'UserInfoController@getStorageFile')->name('download/result');


// Temporary url Route
Route::middleware(['auth:' . config('admin-auth.defaults.guard'), 'admin'])
    ->get('/show/{filename}', 'UserInfoController@getStorageFileUrl')->name('show/result');



